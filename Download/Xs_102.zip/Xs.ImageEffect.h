#pragma once
#include "Xs.Main.h"

class Effect
{
public:
    //==========================================================
    // 模糊家族（Blur Family）
    //==========================================================

    /// <summary>
    /// 高斯模糊（高质量、较慢）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="sigma">模糊强度，推荐 2.0~4.0</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void BlurGaussian(sf::Texture& texture, double sigma);

    /// <summary>
    /// 盒式模糊（速度快、质量一般）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="radius">模糊半径，推荐 2~6</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void BoxBlur(sf::Texture& texture, std::size_t radius);

    /// <summary>
    /// 运动模糊（方向性拖影）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="angleDeg">方向角度（0° 向右，90° 向下）</param>
    /// <param name="strength">强度，推荐 0.15~0.35</param>
    /// <param name="samples">采样数，推荐 8~16</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void BlurMotion(sf::Texture& texture, float angleDeg, float strength,
        std::size_t samples);

    /// <summary>
    /// 径向模糊（从中心向外扩散，适合爆炸、冲击波）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="strength">强度，推荐 0.25~0.5</param>
    /// <param name="samples">采样数，推荐 10~16</param>
    /// <param name="centerX">中心横坐标（归一化 0~1）</param>
    /// <param name="centerY">中心纵坐标（归一化 0~1）</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void BlurRadial(sf::Texture& texture, float strength,
        std::size_t samples, float centerX, float centerY);

    /// <summary>
    /// 旋转模糊（漩涡感，适合能量场、眩晕）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="angleDeg">旋转角度，推荐 15~90</param>
    /// <param name="samples">采样数，推荐 10~20</param>
    /// <param name="centerX">中心横坐标（归一化 0~1）</param>
    /// <param name="centerY">中心纵坐标（归一化 0~1）</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void BlurSpin(sf::Texture& texture, float angleDeg,
        std::size_t samples, float centerX, float centerY);

    //==========================================================
    // 几何 / 光学扭曲（Geometric & Optical）
    //==========================================================

    /// <summary>
    /// 鱼眼效果（桶形畸变）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="strength">强度，推荐 0.25~0.5</param>
    /// <param name="centerX">中心横坐标（归一化 0~1）</param>
    /// <param name="centerY">中心纵坐标（归一化 0~1）</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void Fisheye(sf::Texture& texture, float strength,
        float centerX, float centerY);

    /// <summary>
    /// 色差效果（RGB 通道分离，科幻感）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="strength">强度，推荐 0.1~0.25</param>
    /// <param name="centerX">中心横坐标（归一化 0~1）</param>
    /// <param name="centerY">中心纵坐标（归一化 0~1）</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void ChromaticAberration(sf::Texture& texture, float strength,
        float centerX, float centerY);

    /// <summary>
    /// 热浪扭曲（火焰、空气扰动）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="amplitude">扰动幅度，推荐 0.1~0.2</param>
    /// <param name="frequency">波动频率，推荐 20~30</param>
    /// <param name="phase">相位（随时间递增）</param>
    /// <param name="noiseStrength">噪声强度，推荐 0.3~0.5</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void HeatHaze(sf::Texture& texture, float amplitude, float frequency,
        float phase, float noiseStrength);

    /// <summary>
    /// 黑洞扭曲（引力吸入效果）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="strength">强度，推荐 0.3~0.6</param>
    /// <param name="centerX">中心横坐标（归一化 0~1）</param>
    /// <param name="centerY">中心纵坐标（归一化 0~1）</param>
    /// <param name="power">衰减指数，推荐 1.5~2.5</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void BlackHole(sf::Texture& texture, float strength,
        float centerX, float centerY, float power);

    /// <summary>
    /// 水波扭曲
    /// </summary>
    /// <param name="texture">目标图像</param>
    /// <param name="centerX">x</param>
    /// <param name="centerY">y</param>
    /// <param name="radius">环半径</param>
    /// <param name="width">环宽度</param>
    /// <param name="amplitude">扭曲强度</param>
    static void WaterRipple(
        sf::Texture& texture,
        int centerX,
        int centerY,
        int radius,
        int width,
        float amplitude);

    //==========================================================
    // 羽化（Feathering）
    //==========================================================

    /// <summary>
    /// 圆形羽化图像
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="strength">强度，推荐 0.2~0.4</param>
    static void FeatherCircle(sf::Texture& texture, float strength = 0.3f);

    /// <summary>
    /// 方形羽化图像
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="strength">强度，推荐 0.2~0.4</param>
    static void FeatherRect(sf::Texture& texture, float strength = 0.3f);

    //==========================================================
    // 颜色调整（Color Adjustment）
    //==========================================================

    /// <summary>
    /// 反色（颜色取反）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    static void Invert(sf::Texture& texture);

    /// <summary>
    /// 对比度调整
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="contrast">对比度，推荐 0.8~1.4</param>
    static void AdjustContrast(sf::Texture& texture, float contrast);

    /// <summary>
    /// 灰度化
    /// </summary>
    /// <param name="texture">目标纹理</param>
    static void Gray(sf::Texture& texture);

    /// <summary>
    /// 亮度调整
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="brightness">亮度偏移，推荐 -0.2~0.3</param>
    static void AdjustBrightness(sf::Texture& texture, float brightness);

    /// <summary>
    /// 饱和度调整
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="saturation">饱和度，推荐 0.0~1.5</param>
    static void AdjustSaturation(sf::Texture& texture, float saturation);

    /// <summary>
    /// Gamma 校正
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="gamma">Gamma 值，标准 2.2，推荐 0.8~2.2</param>
    static void AdjustGamma(sf::Texture& texture, float gamma);

    //==========================================================
    // 像素与风格化（Pixel & Stylizing）
    //==========================================================

    /// <summary>
    /// 马赛克效果
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="blockSize">方块大小，推荐 4~16</param>
    static void Mosaic(sf::Texture& texture, std::size_t blockSize);

    /// <summary>
    /// 卡通化（边缘 + 色阶压缩）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="edgeRadius">边缘半径，推荐 1</param>
    /// <param name="colorLevels">色阶数量，推荐 4~8</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void Cartoon(sf::Texture& texture, std::size_t edgeRadius,
        std::size_t colorLevels);

    /// <summary>
    /// 故障特效（赛博朋克风格）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="strength">强度，推荐 0.15~0.4</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void Glitch(sf::Texture& texture, float strength);

    //==========================================================
    // 发光（Glow）
    //==========================================================

    /// <summary>
    /// 外发光
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="radius">发光半径，推荐 6~12</param>
    /// <param name="color">发光颜色</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void GlowOuter(sf::Texture& texture, float radius,
        const sf::Color& color);

    /// <summary>
    /// 内发光
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="radius">发光半径，推荐 4~8</param>
    /// <param name="color">发光颜色</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void GlowInner(sf::Texture& texture, float radius,
        const sf::Color& color);

    //==========================================================
    // 颜色替换（Color Replacement）
    //==========================================================

    /// <summary>
    /// HSV 颜色替换（视觉更准确）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="targetColor">目标颜色</param>
    /// <param name="newColor">新颜色</param>
    /// <param name="hueTolerance">色相差，推荐 10~25</param>
    /// <param name="saturationTolerance">饱和度容差，推荐 0.2~0.4</param>
    /// <param name="valueTolerance">明度容差，推荐 0.2~0.4</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void ReplaceColorHSV(sf::Texture& texture,
        const sf::Color& targetColor,
        const sf::Color& newColor,
        float hueTolerance,
        float saturationTolerance,
        float valueTolerance);

    /// <summary>
    /// RGB 颜色替换（性能更高）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="targetColor">目标颜色</param>
    /// <param name="newColor">新颜色</param>
    /// <param name="tolerance">容差，推荐 8~20</param>
    /// <param name="downscale">降采样比例，推荐 0.5</param>
    static void ReplaceColorRGB(sf::Texture& texture,
        const sf::Color& targetColor,
        const sf::Color& newColor,
        std::uint8_t tolerance);

    //==========================================================
    // 工具（Utility）
    //==========================================================

    /// <summary>
    /// 缩放纹理（特效前常用 0.5 以提升性能）
    /// </summary>
    /// <param name="texture">目标纹理</param>
    /// <param name="scaleX">横向缩放</param>
    /// <param name="scaleY">纵向缩放</param>
    static void Scale(sf::Texture& texture, float scaleX, float scaleY);
};