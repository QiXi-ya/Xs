#pragma once

#include <Windows.h>

int main(); // 你的真实入口