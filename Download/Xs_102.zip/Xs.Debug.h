#pragma once
#include "Xs.Main.h"

namespace xs
{
	class XDebug
	{
	public:
		/// <summary>
		/// 写入日志
		/// </summary>
		/// <param name="text">要写入的日志内容</param>
		/// <param name="LogFilePath">日志文件路径</param>
		static void Log(std::string text, std::wstring LogFilePath = L"QxDebug.log");
		/// <summary>
		/// 使用MessageBox显示调试信息
		/// </summary>
		/// <param name="text">要显示的调试信息</param>
		static void DebugMsg(std::wstring text);
		/// <summary>
		/// 使用MessageBox显示调试信息
		/// </summary>
		/// <param name="text">要显示的调试信息</param>
		static void DebugMsg(std::string text);
		/// <summary>
		/// 将调试信息送至缓冲区。
		/// </summary>
		/// <param name="text">调试信息</param>
		/// <param name="text">等级</param>
		static void DebugPut(std::wstring text,int level = 0);
		/// <summary>
		/// 将调试信息送至缓冲区。
		/// </summary>
		/// <param name="text">调试信息</param>
		/// <param name="text">等级</param>
		static void DebugPut(std::string text, int level = 0);
		/// <summary>
		/// 获取缓冲区的调试信息
		/// </summary>
		/// <returns>缓冲区的调试信息</returns>
		static std::vector<std::pair<std::wstring,int>> GetDebug();
		/// <summary>
		/// 获取缓冲区的调试信息
		/// </summary>
		/// <returns>缓冲区的调试信息</returns>
		static std::vector<std::pair<std::string, int>> GetDebugA();
		/// <summary>
		/// 清除调试信息缓冲区
		/// </summary>
		static void ClearDebug();
	};
}