#pragma once

#pragma warning(disable: 4996 4244 4819 4828 4834 4819 4305)

#define SFML_STATIC

const double M_PI = 3.14159265358979323846;

#include <Windows.h>
#include <string>
#include <ctime>
#include <fstream>
#include <filesystem>
#include <dwmapi.h>
#include <math.h>
#pragma comment(lib, "dwmapi.lib")
#include <thread>
#include <map>
#include <unordered_map>
#include <imm.h>
#pragma comment(lib, "imm32.lib")

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Network.hpp>

#pragma comment(lib, "sfml-graphics-s.lib")
#pragma comment(lib, "sfml-window-s.lib")
#pragma comment(lib, "sfml-system-s.lib")
#pragma comment(lib, "sfml-audio-s.lib")
#pragma comment(lib, "sfml-network-s.lib")

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "freetype.lib")

// ===== SFML 静态音频依赖 =====
#pragma comment(lib, "flac.lib")
#pragma comment(lib, "ogg.lib")
#pragma comment(lib, "vorbis.lib")
#pragma comment(lib, "vorbisfile.lib")

//全局命名空间定义
using namespace sf;

using RenWin = RenderWindow;
using Rt = RenderTarget;
using Rtt = RenderTexture;

//托盘消息
#define WM_TRAY_CALLBACK (WM_USER + 1)