#pragma once

#include "Xs.Main.h"

namespace xs
{
    //字符串
    class XString 
    {
    public:
        //转换
        class Convert
        {
        public:
            // UTF-8 std::string <-> std::wstring
            static std::wstring utf8_to_wstring(const std::string& utf8);
            static std::string wstring_to_utf8(const std::wstring& wstr);

            // GBK std::string <-> std::wstring
            static std::wstring gbk_to_wstring(const std::string& gbk);
            static std::string wstring_to_gbk(const std::wstring& wstr);

            // UTF-8 <-> GBK
            static std::string utf8_to_gbk(const std::string& utf8);
            static std::string gbk_to_utf8(const std::string& gbk);
        };
       //查找
        class Find
        {
        public:
            static size_t find(const std::string& str, const std::string& sub, size_t offset = 0);
            static size_t find(const std::wstring& str, const std::wstring& sub, size_t offset = 0);

            static bool contains(const std::string& str, const std::string& sub);
            static bool contains(const std::wstring& str, const std::wstring& sub);
        };
       //替换
        class Replace
        {
        public:
            static std::string replace(const std::string& str,
                const std::string& from,
                const std::string& to);

            static std::wstring replace(const std::wstring& str,
                const std::wstring& from,
                const std::wstring& to);
        };
        //删除
        class Remove
        {
        public:
            static std::string remove(const std::string& str, const std::string& sub);
            static std::wstring remove(const std::wstring& str, const std::wstring& sub);
        };
        //大小写
        class Case
        {
        public:
            static std::string ToLower(std::string str);
            static std::string ToUpper(std::string str);

            static std::wstring ToLower(std::wstring str);
            static std::wstring ToUpper(std::wstring str);
        };
        //分割
        class Split
        {
        public:
            static std::vector<std::string> split(const std::string& str, char delimiter);
            static std::vector<std::wstring> split(const std::wstring& str, wchar_t delimiter);
        };
    };
}