#pragma once
#include "Xs.Main.h"

namespace xs
{
	//窗口圆角类型
	enum WindowCorner
	{
		CORNER_ROUND,//圆角
		CORNER_SMALLROUND,//小圆角
		CORNER_NOROUND//方角
	};

	//窗口背景
	enum WindowBackType
	{
		BACKTYPE_AUTO,//自动
		BACKTYPE_BLUR,//模糊
		BACKTYPE_HEAVYMICA,//重度云母
		BACKTYPE_MICA,//云母
		BACKTYPE_NULL//无
	};

	//窗口
	class XWindow
	{
	public:
		/// <summary>
		/// 高级OpenGL设置
		/// </summary>
		class Advanced
		{
		public:
			/// <summary>
			/// 设置窗口的抗锯齿大小
			/// </summary>
			/// <param name="level">要设置的抗锯齿大小</param>
			/// <param name="注意">请在调用窗口创建函数前设置</param>
			static void SetWindowAntiAliasingLevel(unsigned int level);
			/// <summary>
			/// 设置深度缓冲位数
			/// </summary>
			/// <param name="Bits">要设置的位数</param>
			/// <param name="注意">请在调用窗口创建函数前设置</param>
			static void SetDepthBits(unsigned int Bits);
			/// <summary>
			/// 设置模板缓冲位数
			/// </summary>
			/// <param name="Bits">要设置的位数</param>
			/// <param name="注意">请在调用窗口创建函数前设置</param>
			static void SetStencilBits(unsigned int Bits);
			/// <summary>
			/// 设置窗口要使用的OpenGL版本
			/// </summary>
			/// <param name="version">要设置的版本</param>
			/// <param name="注意">请在调用窗口创建函数前设置</param>
			static void SetOpenGLVersion(unsigned int version);
			/// <summary>
			/// 设置窗口上下文属性
			/// </summary>
			/// <param name="flags">要设置的属性</param>
			/// <param name="注意">请在调用窗口创建函数前设置</param>
			static void SetAttributeFlags(ContextSettings::Attribute flags);
			/// <summary>
			/// 设置sRGB缓冲
			/// </summary>
			/// <param name="enable">是否启用</param>
			/// <param name="注意">请在调用窗口创建函数前设置</param>
			static void SetSRgbCapable(bool enable);
		};

		/// <summary>
		/// 启用程序的高DPI感知
		/// </summary>
		static void SetDPIAware();
		/// <summary>
		/// 创建窗口
		/// </summary>
		/// <param name="Dest">目标窗口</param>
		/// <param name="x">坐标：x，小于0时默认</param>
		/// <param name="y">坐标：y，小于0时默认</param>
		/// <param name="w">窗口宽，小于0时默认</param>
		/// <param name="h">窗口高，小于0时默认</param>
		/// <param name="title">窗口标题，空值时默认</param>
		/// <param name="style">窗口样式</param>
		/// <param name="state">窗口类型</param>
		/// <param name="setting">OpenGL设置</param>
		static void CreateGraphWindow(RenWin& Dest, int x, int y, int w, int h, std::string title = "window", uint32_t style = 7U, sf::State state = State::Windowed);
		/// <summary>
		/// 帧刷新窗口
		/// </summary>
		/// <param name="fps">帧率上限</param>
		/// <param name="Dest">目标窗口</param>
		static void DelayFps(int fps, RenWin& Dest);

		/// <summary>
		/// 设置背景颜色
		/// </summary>
		/// <param name="color">背景颜色</param>
		static void SetBackGroundColor(Color color);
		/// <summary>
		/// 判断当前窗口是否为焦点窗口
		/// </summary>
		/// <param name="Dest">目标窗口</param>
		/// <returns></returns>
		static bool IsFocus(RenWin& Dest);

		/// <summary>
		/// 设置窗口标题
		/// </summary>
		/// <param name="Dest">目标窗口</param>
		/// <param name="title">标题</param>
		static void SetTitle(RenWin& Dest, const String& title);

		/// <summary>
		/// 从文件中设置窗口的图标
		/// </summary>
		/// <param name="Dest">目标窗口</param>
		/// <param name="path">文件路径</param>
		static void SetIcon(RenWin& Dest, const String& path);

		/// <summary>
		/// 设置鼠标在窗口上是否可见
		/// </summary>
		/// <param name="Dest">目标窗口</param>
		/// <param name="visible">是否可见</param>
		static void SetMouseCursorVisible(RenWin& Dest, bool visible);

		/// <summary>
		/// 移动窗口
		/// </summary>
		/// <param name="Dest">目标窗口</param>
		/// <param name="x">坐标：x</param>
		/// <param name="y">坐标：y</param>
		static void MoveWindow(RenWin& Dest, int x, int y);

		/// <summary>
		/// 设置窗口大小
		/// </summary>
		/// <param name="Dest">目标大小</param>
		/// <param name="width">设置的宽</param>
		/// <param name="height">设置的高</param>
		static void SetWindowSize(RenWin& Dest, int width, int height);

		/// <summary>
		/// 获取窗口大小
		/// </summary>
		/// <param name="Dest">目标窗口</param>
		/// <returns></returns>
		static Vector2i GetWindowSize(RenWin& Dest);

		/// <summary>
		/// 获取窗口坐标
		/// </summary>
		/// <param name="Dest">目标窗口</param>
		/// <returns></returns>
		static Vector2i GetWindowPos(RenWin& Dest);

		/// <summary>
		/// 设置窗口大小的最小值
		/// </summary>
		/// <param name="Dest">目标窗口</param>
		/// <param name="width">最小的宽</param>
		/// <param name="height">最小的高</param>
		static void SetWindowMinSize(RenWin& Dest, int width, int height);

		/// <summary>
		/// 设置鼠标是否可见
		/// </summary>
		/// <param name="window">目标窗口</param>
		/// <param name="visible">是否可见</param>
		static void SetMouseVisible(RenWin& window,bool visible);

		/// <summary>
		/// 设置垂直同步
		/// </summary>
		/// <param name="window">目标窗口</param>
		/// <param name="enable">是否启用</param>
		static void SetVerticalSync(RenWin& window,bool enable);

		/// <summary>
		/// 最大化窗口
		/// </summary>
		/// <param name="window">目标窗口</param>
		static void MaxWindow(RenWin& window);
		/// <summary>
		/// 最小化窗口
		/// </summary>
		/// <param name="window">目标窗口</param>
		static void MinWindow(RenWin& window);
		/// <summary>
		/// 还原窗口
		/// </summary>
		/// <param name="window">目标窗口</param>
		static void RestoreWindow(RenWin& window);
		/// <summary>
		/// 设置窗口是否可见
		/// </summary>
		/// <param name="window">目标窗口</param>
		static void SetWindowVisible(RenWin& window,bool IsVisible);

		/// <summary>
		/// 为指定窗口添加窗口样式
		/// </summary>
		/// <param name="hwnd">目标窗口句柄</param>
		/// <param name="style">要添加的样式</param>
		/// <returns></returns>
		static bool AddWindowStyle(HWND hwnd, LONG style);
		/// <summary>
		/// 为指定窗口添加窗口样式
		/// </summary>
		/// <param name="window">目标窗口</param>
		/// <param name="style">要添加的样式</param>
		/// <returns></returns>
		static bool AddWindowStyle(RenWin& window, LONG style);

		/// <summary>
		/// 为指定窗口添加拓展窗口样式
		/// </summary>
		/// <param name="hwnd">目标窗口句柄</param>
		/// <param name="style">要添加的样式</param>
		/// <returns></returns>
		static bool AddWindowExStyle(HWND hwnd, LONG style);
		/// <summary>
		/// 为指定窗口添加拓展窗口样式
		/// </summary>
		/// <param name="window">目标窗口</param>
		/// <param name="style">要添加的样式</param>
		/// <returns></returns>
		static bool AddWindowExStyle(RenWin& window, LONG style);

		/// <summary>
		/// 为指定窗口移除窗口样式
		/// </summary>
		/// <param name="hwnd">目标窗口句柄</param>
		/// <param name="style">要移除的样式</param>
		/// <returns></returns>
		static bool RemoveWindowStyle(HWND hwnd, LONG style);
		/// <summary>
		/// 为指定窗口移除窗口样式
		/// </summary>
		/// <param name="window">目标窗口</param>
		/// <param name="style">要移除的样式</param>
		/// <returns></returns>
		static bool RemoveWindowStyle(RenWin& window, LONG style);

		/// <summary>
		/// 为指定窗口移除拓展窗口样式
		/// </summary>
		/// <param name="hwnd">目标窗口句柄</param>
		/// <param name="style">要移除的样式</param>
		/// <returns></returns>
		static bool RemoveWindowExStyle(HWND hwnd, LONG style);
		/// <summary>
		/// 为指定窗口移除拓展窗口样式
		/// </summary>
		/// <param name="window">目标窗口</param>
		/// <param name="style">要移除的样式</param>
		/// <returns></returns>
		static bool RemoveWindowExStyle(RenWin& window, LONG style);

		/// <summary>
		/// 关闭窗口
		/// </summary>
		/// <param name="window">要关闭的窗口</param>
		static void CloseWIndow(RenWin& window);

		class DWM
		{
		public:
			/// <summary>
			/// 设置窗口圆角选项
			/// </summary>
			/// <param name="hwnd">目标窗口句柄</param>
			/// <param name="round">圆角类型</param>
			static void SetWindowRoundCorner(HWND hwnd, WindowCorner round);
			/// <summary>
			/// 设置窗口圆角选项
			/// </summary>
			/// <param name="window">目标窗口</param>
			/// <param name="round">圆角类型</param>
			static void SetWindowRoundCorner(RenWin& window, WindowCorner round);

			/// <summary>
			/// 设置窗口边框颜色
			/// </summary>
			/// <param name="hwnd">目标窗口句柄</param>
			/// <param name="color">边框颜色</param>
			static void SetWindowBorderColor(HWND hwnd, Color color);
			/// <summary>
			/// 设置窗口边框颜色
			/// </summary>
			/// <param name="window">目标窗口</param>
			/// <param name="color">边框颜色</param>
			static void SetWindowBorderColor(RenWin& window, Color color);

			/// <summary>
			/// 设置窗口标题栏颜色
			/// </summary>
			/// <param name="hwnd">目标窗口句柄</param>
			/// <param name="color">标题栏颜色</param>
			static void SetWindowTitleBarColor(HWND hwnd, Color color);
			/// <summary>
			/// 设置窗口标题栏颜色
			/// </summary>
			/// <param name="window">目标窗口</param>
			/// <param name="color">标题栏颜色</param>
			static void SetWindowTitleBarColor(RenWin& window, Color color);

			/// <summary>
			/// 设置窗口标题文字颜色
			/// </summary>
			/// <param name="hwnd">目标窗口句柄</param>
			/// <param name="color">标题文字颜色</param>
			static void SetWindowTitleTextColor(HWND hwnd, Color color);
			/// <summary>
			/// 设置窗口标题文字颜色
			/// </summary>
			/// <param name="window">目标窗口</param>
			/// <param name="color">标题文字颜色</param>
			static void SetWindowTitleTextColor(RenWin& window, Color color);

			/// <summary>
			/// 设置窗口背景类型
			/// </summary>
			/// <param name="hwnd">目标窗口句柄</param>
			/// <param name="type">背景类型</param>
			static void SetWindowBackType(HWND hwnd, WindowBackType type);
			/// <summary>
			/// 设置窗口背景类型
			/// </summary>
			/// <param name="window">目标窗口</param>
			/// <param name="type">背景类型</param>
			static void SetWindowBackType(RenWin& window, WindowBackType type);

			/// <summary>
			/// 设置窗口深色模式
			/// </summary>
			/// <param name="hwnd">目标窗口句柄</param>
			/// <param name="EnableDarkMode">是否启用深色模式</param>
			static void SetWindowDarkMode(HWND hwnd, bool EnableDarkMode);
			/// <summary>
			/// 设置窗口深色模式
			/// </summary>
			/// <param name="window">目标窗口</param>
			/// <param name="EnableDarkMode">是否启用深色模式</param>
			static void SetWindowDarkMode(RenWin& window, bool EnableDarkMode);

			/// <summary>
			/// 启用或禁用窗口阴影
			/// </summary>
			/// <param name="hwnd">目标窗口句柄</param>
			/// <param name="enable">是否启用</param>
			static void EnableWindowShadow(HWND hwnd, bool enable);
			/// <summary>
			/// 启用或禁用窗口阴影
			/// </summary>
			/// <param name="window">目标窗口</param>
			/// <param name="enable">是否启用</param>
			static void EnableWindowShadow(RenWin& window, bool enable);

			/// <summary>
			/// 扩展客户区到非客户区（用于自定义标题栏）
			/// </summary>
			/// <param name="hwnd">目标窗口句柄</param>
			/// <param name="top">上边距</param>
			/// <param name="bottom">下边距</param>
			/// <param name="left">左边距</param>
			/// <param name="right">右边距</param>
			static void ExtendIntoClientArea(HWND hwnd, int top, int bottom, int left, int right);
			/// <summary>
			/// 扩展客户区到非客户区（用于自定义标题栏）
			/// </summary>
			/// <param name="window">目标窗口</param>
			/// <param name="top">上边距</param>
			/// <param name="bottom">下边距</param>
			/// <param name="left">左边距</param>
			/// <param name="right">右边距</param>
			static void ExtendIntoClientArea(RenWin& window, int top, int bottom, int left, int right);

			/// <summary>
			/// 禁用窗口动画过渡效果
			/// </summary>
			/// <param name="hwnd">目标窗口句柄</param>
			/// <param name="disable">是否禁用</param>
			static void DisableTransitionAnimation(HWND hwnd, bool disable);
			/// <summary>
			/// 禁用窗口动画过渡效果
			/// </summary>
			/// <param name="window">目标窗口</param>
			/// <param name="disable">是否禁用</param>
			static void DisableTransitionAnimation(RenWin& window, bool disable);
		};
	};
}
